import React from 'react';
function App() {
  return <h1>Hidudu React Web App</h1>;
}
export default App;