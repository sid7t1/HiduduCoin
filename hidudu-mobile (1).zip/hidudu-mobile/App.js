import React from 'react';
import { View, Text } from 'react-native';

export default function App() {
  return (
    <View style={{ padding: 20 }}>
      <Text>Hidudu Mobile App (Expo)</Text>
    </View>
  );
}